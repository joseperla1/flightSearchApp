import {
  require_react
} from "./chunk-XFZ2DVVZ.js";
export default require_react();
//# sourceMappingURL=react.js.map
