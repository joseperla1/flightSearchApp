function script(){
    
// Array to hold all destination info //
const destinationArray = [];

// Card Class to assign info from API calls //
class Card {
    constructor(image, name, budget, airline) {
        this.image = image;
        this.name = name;
        this.budget = budget;
    }
}

const destinationInput = document.getElementById("destination");
const budgetInput = document.getElementById("budget");

// Function to fetch flight info from API //
const fetchFlightInfo = async () => {

}
}   
export default script